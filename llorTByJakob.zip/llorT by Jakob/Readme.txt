----All-in-One----
Hier werden automatisch alle infos in die "all in one.txt" geschrieben.
IP: Hier kannst du am anfang den NAMEN von den IPs eingeben...
KeyCracker: Du musst schon im WLAN eingeloggt sein und einen Namen
eingeben der dann dem Key zugewiesen wird
Remote Desktop: Der PC muss im gleichen internet sein!



########
WICHTIG:
Du brauchst für All-in-One und KeyCracker eine "WLAN" verbindung

